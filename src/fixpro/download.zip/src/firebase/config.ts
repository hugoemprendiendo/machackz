export const firebaseConfig = {
  "projectId": "studio-8021924499-46b5d",
  "appId": "1:252573756740:web:7d7b1114868f94a8f7fb11",
  "apiKey": "AIzaSyC06hVNDt9rKVqVuqqPPuSG855Qtwt5YgA",
  "authDomain": "studio-8021924499-46b5d.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "252573756740"
};
